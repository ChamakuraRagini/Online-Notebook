<?php
include ('dbconn.php');
?>
<!DOCTYPE html>





<html>
<head><title>Computer Networks</title></head>
<link href="/forum/styles/1.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body class="w3-container w3-gray">
<?php  session_start();  ?>
<nav class="frstclss">
<ul>
  <li><a class="active" href="home.php">Home</a></li>
  <li><a href="up.php">Upload</a></li>
  <li><a href="aboutus.php">About Us</a></li>
  <li><a href="discussion.php">Discussion</a></li>
    
  <li style="float:right"><a href="logout.php">Logout</a></li>
  
   <li style="float:right;margin-left:50px;color:white"><a href="view.php"> Welcome <?php echo $_SESSION['user_name'] ?> </a></li> 
</ul>
</nav>
<div class="pane">
<div id="header">
<label>Computer Networks</label>
</div>
<div id="body">
	<table width="80%" border="1">
    <tr>
    <th colspan="5">your uploads...<label><a href="up.php">upload new files...</a></label></th>
    </tr>
    <tr>
    <td>File Name</td>
    <td>File Type</td>
    <td>File Size(KB)</td>
    <td>View</td>
	<td>download</td>
    </tr>
    <?php
	
	
	$usern= $_SESSION['user_name'] ;
	$sql="SELECT * FROM tbl_uploads where  subject= 'Computer Networks'";
	$result_set=mysqli_query($con,$sql);
	while($row=mysqli_fetch_array($result_set))
	{
		?>
        <tr>
        <td><?php echo $row['file'] ?></td>
        <td><?php echo $row['type'] ?></td>
        <td><?php echo $row['size'] ?></td>
        <td><a href="uploads/<?php echo $row['file'] ?>" target="_blank">view file</a></td>
		
		
		 <td><a href="down.php?file=<?php echo $row['file']?>">Download file</a></td>
		
		
		
	
		 
		 
        </tr>
        <?php
	}
	?>
    </table>
    </div>
</div>
</body>
</html>