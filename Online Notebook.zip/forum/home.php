<!DOCTYPE html>
<html>
<head>
<style>
div.img{
         text-align: center;  
       }
nav.frstclss ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

nav.frstclss li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

nav.frstclss li a:hover:not(.active) {
    background-color:  #4CAF50;
}
.active {
    background-color: #4CAF50;
}
nav.secclss ul{
list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: white;
}
nav.secclss li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
nav.secclss li a:hover:not(.active) {
    background-color:  #4CAF50;
}

</style>
</head>
<body class="w3-container w3-gray">
<?php  session_start();  ?>
<nav class="frstclss">
<ul>
  <li><a class="active" href="home.php">Home</a></li>
  <li><a href="up.php">Upload</a></li>
  <li><a href="aboutus.php">About US</a></li>
  <li><a href="discussion.php">Discussion</a></li>
    
  <li style="float:right"><a href="logout.php">Logout</a></li>
  
   <li style="float:right;margin-left:50px;color:white"><a href="view.php"> Welcome <?php echo $_SESSION['user_name'] ?> </a></li> 
</ul>
</nav>
<div class="img">
            <img src="13.jpg" width=100% height="450"></div>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<div class="w3-container w3-green">
  <p>First Year Subjects:</p>
 <div class="w3-container w3-white">
 <nav class="secclss">
 <ul><li><a href="math.php">MATHEMATICS</a></li><li><a href="clang.php">C LANGUAGE</a></li><li><a href="phy.php">PHYSICS</a></li><li><a href="ds.php">DATA STRUCTURES</a></li></ul>
 </nav>  
</div>

<div class="w3-container w3-green">
  <p>Second Year Subjects:</p>
</div>
<div class="w3-container w3-white">
 <nav class="secclss">
 <ul><li><a href="cpp.php">OOPS THROUGH C++</a></li><li><a href="se.php">SOFTWARE ENGINEERING</a></li><li><a href="daa.php">DESIGN OF ALGORITHMS</a></li><li><a href="os.php">OPERATING SYSTEMS</a></li></ul>
 </nav>  
</div>

<div class="w3-container w3-green">
  <p>Third Year Subjects:</p>
</div>
<div class="w3-container w3-white">
  <nav class="secclss">
 <ul><li><a href="cn.php">COMPUTER NETWORKS</a></li><li><a href="cd.php">COMPILER DESIGN</a></li><li><li><a href="dbms.php">DBMS</a></li><li><a href="wt.php">WEB TECHNOLOGIES</a></li></ul>
</nav>  
</div>

<div class="w3-container w3-green">
  <p>Fourth Year Subjects:</p>
</div>
<div class="w3-container w3-white">
  <nav class="secclss">
 <ul><li><a href="ns.php">NETWORK SECURITY</a></li><li><a href="dc.php">DISTRIBUTED COMPUTING</a></li><li><a href="sc.php">SOFT COMPUTING</a></li><li><a href="mc.php">MOBILE COMPUTING</a></li></ul>
 </nav>  
</div>


</body>
</html>