<?php
	
	include ('content_function.php');
	addview($_GET['cid'], $_GET['scid'], $_GET['tid']);
?>
<html>
<head><title>forum page</title></head>
<link href="/forum/styles/1.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body class="w3-container w3-gray">
<?php  session_start();  ?>
<nav class="frstclss">
<ul>
  <li><a  href="home.php">Home</a></li>
  <li><a href="up.php">Upload</a></li>
  <li><a href="aboutus.php">About Us</a></li>
  <li><a href="discussion.php" class="active">Discussion</a></li>
    
  <li style="float:right"><a href="logout.php">Logout</a></li>
  
   <li style="float:right;margin-left:50px;color:white"><a href="view.php"> Welcome <?php echo $_SESSION['user_name'] ?> </a></li> 
</ul>
</nav>
	<div class="pane">
		<div class="header"><h1><a href="/forum">FORUM PAGE</a></h1></div>
		<div class="loginpane">
			
		</div>
		<div class="forumdesc">
			
			<?php
				replylink($_GET['cid'], $_GET['scid'], $_GET['tid']);
			?>
		</div>
		<div class="content1">
		<?php
		
			disptopic($_GET['cid'], $_GET['scid'], $_GET['tid']);
			echo "<div class='content'><p>All Replies (".countReplies($_GET['cid'], $_GET['scid'], $_GET['tid']).")
				  </p></div>";
			dispreplies($_GET['cid'], $_GET['scid'], $_GET['tid']);
			
		?>
		</div>
	</div>
</body>
</html>