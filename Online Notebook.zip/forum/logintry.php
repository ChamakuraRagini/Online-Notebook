<!doctype html>  
<html>  
<head>  
<title>Login</title>  
   
</head>  
<link href="/forum/styles/1.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body class="w3-container w3-gray">  


<div class="container">
  <div class="info">
    <h1> LOGIN</h1>
  </div>
</div>

<div class="form">
    <div class="thumbnail"><img src="in.png" ></div> 
			
			
 
<form action="" method="POST" class="login-form">  
<input type="text"  placeholder="username" class="demoInputBox" name="user" required><br />  
<input type="password" placeholder="password" class="demoInputBox" name="pass" required><br />   
<input type="submit" value="LOGIN" name="submit"  /> 
<input type="reset" value="RESET" ><br> 
<p class="message">Not registered? <a href="regtry.php">Create an account</a></p> 
</form>  
</div>


<?php  
if(isset($_POST["submit"])){  
  
if(!empty($_POST['user']) && !empty($_POST['pass'])) {  
    $user=$_POST['user'];  
    $pass=$_POST['pass'];  
  
   include('dbconn.php');
   
  
    $query=mysqli_query($con,"SELECT * FROM users WHERE user_name='".$user."' AND password='".$pass."'");  
    $numrows=mysqli_num_rows($query);  
    if($numrows!=0)  
    {  
    while($row=mysqli_fetch_assoc($query))  
    {  
    $dbusername=$row['user_name'];  
    $dbpassword=$row['password'];  
    }  
  
    if($user == $dbusername && $pass == $dbpassword)  
    {  
    session_start();  
    $_SESSION['user_name']=$user;  
  
    /* Redirect browser */  
	echo '<script language="javascript">';
    echo 'alert("Welcome to ONLINE NOTEBOOK!")';

	echo '</script>';

echo '<script language="javascript">';
echo 'window.location="home.php"';
echo '</script>';
    }  
    } else {  
      echo '<script language="javascript">';
    echo 'alert("Invalid username or password!!")';
	echo '</script>';
    }  
} 
}  
?>  
</body>  
</html> 