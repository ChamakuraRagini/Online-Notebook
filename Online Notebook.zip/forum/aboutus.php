<html>
<html xmlns="http://www.w3.org/1999/xhtml">
<link rel="stylesheet" href="style.css" type="text/css" /> 
<link href="/forum/styles/1.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body class="w3-container w3-gray" style="color:gray">
<?php  session_start();  ?>
<nav class="frstclss">
<ul>
  <li><a  href="home.php">Home</a></li>
  <li><a href="up.php" >Upload</a></li>
  <li><a href="aboutus.php" class="active">About Us</a></li>
  <li><a href="discussion.php">Discussion</a></li>
    
  <li style="float:right"><a href="logout.php">Logout</a></li>
  
   <li style="float:right;margin-left:50px;color:white"><a href="view.php"> Welcome <?php echo $_SESSION['user_name'] ?> </a></li> 
</ul>
</nav>
<style>
 body{  	
    background-color: azure ;   
    font-family: verdana;  
    font-size: 100%  
        }
	div.lg{
         text-align: center;
         padding-top: 2px;
		 padding-left:150px;
         padding-right:150px;
		 line-height: 50px;
    }
		</style>
<body>		
<center>
  <h2>ONLINE NOTEBOOK</h2></center>
  <div class="lg"> 
<p><h6>During the time of exams or for a general preview,students often try to refer some notes.
Taking notes is an important part of the life of every student.
It is a great way to remember important concepts professor emphasized in class. 
Notes will always provide a useful record of important points for future use and also remind us where the information was sourced.
But there may be times when students may not be able to come to classes or they may not be able to   take notes.
Sometimes there is also a possibility of losing notes taken.</h6></p>
 <h6><p><b>Online NoteBook System</b> tries to resolve these problems by allowing students who have notes to share them online.
This would help other students to refer them when needed.A student must <b>register</b> himself in order to access the system. A registered user can <b>upload,download and view notes.</b>
Students will also be provided with an option to <b>view their uploaded notes</b>(their profile). User can also <b>delete their uploaded files.</b></h6></p>
             
<p><h6>Online NoteBook also provides an easy way of clarifying doubts of students,where a user can post a questions using <b>Discussion Option</b> which can be answered by other users.
Our goal is to help  students by providing an <b>easy and  interactive way of learning.</b></h6></p></div>
<h3>CONTACT US:7032362209</h3>
</body>
</html>