<!doctype html>  
<html>  
<head>  
<title>Register</title>  
  
</head>  
<link href="/forum/styles/1.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">




 
	
	
<body class="w3-container w3-gray"  > 
    
	
	
<div class="container">
  <div class="info">
    <h1> REGISTRATION FORM</h1>
  </div>
</div>


<div class="form">
     <div class="thumbnail"><img src="in.png" ></div> 


            
    
<form  name="registration"    method="POST"   >  

			<input type="text" class="demoInputBox" placeholder="username"  name="user" required>
		
			<input type="text" class="demoInputBox" placeholder="first name" name="firstName" required>
		
			<input type="text" class="demoInputBox" placeholder="last name" name="lastName" required>
		
			<input type="password" class="demoInputBox" placeholder="password" name="pass" required>
		<input type="password" class="demoInputBox" name="confirm_password" placeholder="confirm password" required>
		
			<input type="email" class="demoInputBox" name="userEmail" placeholder="email id" required>
		<table>
			<tr>
			<td><input type="radio" name="gender" value="Male"></td>
			<td> <p class="message1"> Male</p></td>
			<td><input type="radio" name="gender" value="Female"></td>
			<td> <p class="message1"> Female</p></td></tr>
		
			
			<tr><td><input type="checkbox" name="terms" required></td><td><p class="message1"> I accept Terms and Conditions</p></td> </tr>
			</table>
			
			<input type="submit" value="REGISTER" name="reg_user"  /> 
	    <p class="message">Already have an account? <a href="logintry.php">Login</a></p>    
</form> 
</div>













<?php
$flag;
if (isset($_POST['reg_user'])) {
	if(!empty($_POST['user']) && !empty($_POST['pass'])) {  
    $user=$_POST['user'];  
    $pass=$_POST['pass'];  
	$passagain=$_POST['confirm_password'];
    include ('dbconn.php');
	if(strlen($pass)<5){
	 echo '<script language="javascript">';
    echo 'alert("Password is very weak!!")';
	echo '</script>';
	
	
	

	
	$flag=set;
	}
	if ($pass!= $passagain) {
    echo '<script language="javascript">';
    echo 'alert("Password dont match!!")';
	echo '</script>';
	$flag=set;
   }
   
   echo $flag;
   while($flag!='set')
   {
   $query=mysqli_query($con,"SELECT * FROM users WHERE user_name='".$user."'");  
    $numrows=mysqli_num_rows($query);  
    if($numrows==0)  
    {  
    $sql="INSERT INTO users (user_name,password) VALUES('$user','$pass')";  
  
    $result=mysqli_query($con,$sql);  
        if($result){  
    echo '<script language="javascript">';
	
	 session_start();  
	  $_SESSION['user_name']=$user;
    
	
	
	echo '<script language="javascript">';
	echo 'alert("Account Successfully created!!")';
	echo '</script>';
	
	
	echo '<script language="javascript">';
echo 'window.location="home.php"';
echo '</script>';
	
	
	
    } else {  
    echo '<script language="javascript">';
    echo 'alert("Failure!!")';
	echo '</script>';
    }  
  
    } else {  
	echo '<script language="javascript">';
    echo 'alert("That username already exists! Please try again with another.")';
	echo '</script>';
	
	echo '<script language="javascript">';
echo 'window.location="regtry.php"';
echo '</script>';
	
	
    }
}
}
}

?>


  
</body>  
</html> 