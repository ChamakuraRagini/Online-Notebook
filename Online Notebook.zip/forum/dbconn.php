<?php
  $host='localhost';
  $username='root';
  $password='cse';
  $dbname='test';
  $con=mysqli_connect($host,$username,$password,$dbname);
 //echo "connected";
?>
