<?php
include('dbconn.php');
$q="select * from categories";
$select=mysqli_query($con,$q);
while($row=mysqli_fetch_assoc($select))
{
	echo "<h1>".$row['category_title']."</h1>";
}
?>