<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>


@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,800,700,300);
@import url(https://fonts.googleapis.com/css?family=Squada+One);

#text {
  font-family: 'Open Sans', sans-serif;
  height:35px;
  color: hotpink;
  text-decoration: none;
  text-transform: normal;
  font-size: 35px;
  font-weight: 800;
  letter-spacing: -3px;
  line-height: 2;
  text-shadow: #555 3px 2px 0;
  position: relative;
}

#button {
  width: 1090px;
  height: 90px;
  list-style: none;
  margin: 5px 0 0 0; padding: 25px 10px;
  
  position: relative;
  text-align: center;
}
#button {
  display: inline-block;
  width: 173px;
  margin: 0 10px;
  position: relative;
 
}
#button a {
  text-transform: uppercase;
  font-family: 'Squada One', cursive;
  font-weight: 800;
  display: block;
  background: #FFF;
  padding: 1px 10px;
  color: #333;
  font-size: 40px;
  text-align: center;
  text-decoration: none;
  position: relative;
  z-index: 1;
  text-shadow: 
		1px 1px 0px #FFF, 
		2px 2px 0px #999,
		3px 3px 0px #FFF;
	background-image: -webkit-linear-gradient(top, transparent 0%, rgba(0,0,0,.05) 100%);
	-webkit-transition: 1s all;
	background-image: -webkit-linear-gradient(left top, 
		transparent 0%, transparent 25%, 
		rgba(0,0,0,.15) 25%, rgba(0,0,0,.15) 50%, 
		transparent 50%, transparent 75%, 
		rgba(0,0,0,.15) 75%);
  background-size: 4px 4px;
	box-shadow: 
		0 0 0 1px rgba(0,0,0,.4) inset, 
		0 0 20px -5px rgba(0,0,0,.4),
		0 0 0px 3px #FFF inset;
}


#text1 {
  font-family: 'Rouge Script',cursive, sans-serif;
  height:35px;
  color: salmon;
  text-decoration: none;
  text-transform: normal;
  font-size: 35px;
  font-weight: 800;
  letter-spacing: -3px;
  line-height: 2;
  text-shadow: #555 3px 2px 0;
  position: relative;
}

#button1 {
  width: 1090px;
  height: 90px;
  list-style: none;
  margin: 5px 0 0 0; padding: 25px 10px;
  
  position: relative;
  text-align: center;
}
#button1 {
  display: inline-block;
  width: 173px;
  margin: 0 10px;
  position: relative;
 
}
#button1 a {
  text-transform: uppercase;
  font-family: 'Squada One', cursive;
  font-weight: 800;
  display: block;
  background: #FFF;
  padding: 1px 10px;
  color: #333;
  font-size: 40px;
  text-align: center;
  text-decoration: none;
  position: relative;
  z-index: 1;
  text-shadow: 
		1px 1px 0px #FFF, 
		2px 2px 0px #999,
		3px 3px 0px #FFF;
	background-image: -webkit-linear-gradient(top, transparent 0%, rgba(0,0,0,.05) 100%);
	-webkit-transition: 1s all;
	background-image: -webkit-linear-gradient(left top, 
		transparent 0%, transparent 25%, 
		rgba(0,0,0,.15) 25%, rgba(0,0,0,.15) 50%, 
		transparent 50%, transparent 75%, 
		rgba(0,0,0,.15) 75%);
  background-size: 4px 4px;
	box-shadow: 
		0 0 0 1px rgba(0,0,0,.4) inset, 
		0 0 20px -5px rgba(0,0,0,.4),
		0 0 0px 3px #FFF inset;
}













#putimage {
background-color: pink;
background-image:url("2.jpg");
height:260px; 
width:100%; 

}



/*Styling for footer*/
.fa {

  padding: 5px;
  font-size: 25px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 3px 1px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color:white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

.fa-pinterest {
  background: #cb2027;
  color: white;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    border: 1px solid #e7e7e7;
    background-color: black;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: #ddd;
}
* {box-sizing:border-box}
body {font-family: Verdana,sans-serif;margin:0}
.mySlides {display:none}

.slideshow {
	position: relative;
	overflow: hidden;
	width: inherit;
	height: 330px;
	box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
}
.slideshow > div {
	position: absolute;
	max-width: 100%;
	width: 100%;
	height: 330px;
	max-height: 100%;
}
.slideshow>div>img{
height: 100%;
width: 100%;
}

.slideshow-container {
	/*border-top: 1px solid rgba(68, 68, 68, 0.5);
	border-left: 1px solid rgba(68, 68, 68, 0.5);
	border-right: 1px solid rgba(68, 68, 68, 0.5);*/
	border: 1px solid rgba(68, 68, 68, 0.5);
	background-color: #F8F8F9;
	font: normal 10px/1.5em Arial Verdana, sans-serif;
}
.slideshow-container h3 {
	color: #333;
	margin: 0 auto;
	margin-bottom: 10px;
	padding: 10px;
	border-bottom: 1px solid #C0C0C0;
	font-size: 16px;
	background-color: #DEDEDE;
}
.slideshow-container p {
	font-size: 14px;
}
.slideshow-container hr {
	border-top: 1px solid #bababa;
	width: 60%;
	margin: 0 auto;
	margin-bottom: 14px;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}



/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 10px;
  width: 10px;
  margin: 0 2px;
  background-color: black;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.0s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
</style>
</head>
<body background-color="green">

<div class="slideshow-container">
							<div class="slideshow">
							<div class="mySlides fade">
								<div class="numbertext">1/3</div>
									<img src="preview.jpg">
								</div>
							<div class="mySlides fade">
								<div class="numbertext">2/3</div>
									<img src="11.png">
								</div>
							<div class="mySlides fade">
								<div class="numbertext">3/3</div>
									<img src="12.jpg">
								</div>
<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<div id="putimage" style="text-align:center">

<div id="text" >
Wanna start Sharing and Learning...
</div>
<div id="button" >
<a href="logintry.php">Login</a>
</div>
<div id=text1>
ohh...it's your first visit??
</div>
<div id=button1>
<a href="regtry.php">Register</a>
</div>


</div>


<script>
var slideIndex = 0;
showSlides();
var slides,dots;

function showSlides() {
    var i;
    slides = document.getElementsByClassName("mySlides");
    dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 3000); // Change image every 8 seconds
}

function plusSlides(position) {
    slideIndex +=position;
    if (slideIndex> slides.length) {slideIndex = 1}
    else if(slideIndex<1){slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
        slides[slideIndex-1].style.display = "block";  
        dots[slideIndex-1].className += " active";
    }
}

function currentSlide(index) {
    if (index> slides.length) {index = 1}
    else if(index<1){index = slides.length}
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
        slides[index-1].style.display = "block";  
        dots[index-1].className += " active";
    }
}
</script>
<footer style="text-align:center">
<!-- Add font awesome icons -->
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-instagram"></a>
<a href="#" class="fa fa-pinterest"></a>
</footer> 
</body>
 
</html> 