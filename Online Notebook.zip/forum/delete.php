 <?php
include_once ('dbconn.php');
if (isset($_GET['id']) ) {
	$id = $_GET['id'];
}

	  
	  
	  
	  $sql = "DELETE FROM tbl_uploads WHERE id='$id'";

if(mysqli_query($con, $sql)){
	
	 echo '<script language="javascript">';
    echo 'alert("File deleted successfully!")';

	echo '</script>';
	
	echo '<script language="javascript">';
echo 'window.location="view.php"';
echo '</script>';

    

} else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}




   
?>




		
		