<?php
include_once ('dbconn.php');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>My Uploads</title>
<link href="/forum/styles/1.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body class="w3-container w3-gray">
<?php session_start() ?>
<nav class="frstclss">
<ul>
  <li><a  href="home.php">Home</a></li>
  <li><a href="up.php">Upload</a></li>
  <li><a href="aboutus.php">About Us</a></li>
  <li><a href="discussion.php">Discussion</a></li>
    
  <li style="float:right"><a href="logout.php">Logout</a></li>
  
   <li style="float:right;margin-left:50px;color:white" class="active"><a href="view.php"> Welcome <?php echo $_SESSION['user_name'] ?> </a></li> 
</ul>
</nav>

<div class="pane">
<div id="header">
<h4><label>My Uploads</label></h4>
</div>
<div id="body">
<div class="content1">
	<table width="100%" border="1">
    <tr>
    <th colspan="6">your uploads...<label><a href="up.php">upload new files...</a></label></th>
    </tr>
    <tr>
    <td>File Name</td>
    <td>File Type</td>
    <td>File Size(KB)</td>
    <td>View</td>
	<td>download</td>
	<td>delete</td>
    </tr>
	
    <?php
	
	
	$usern= $_SESSION['user_name'] ;
	$sql="SELECT * FROM tbl_uploads where username = '$usern'";
	$result_set=mysqli_query($con,$sql);
	while($row=mysqli_fetch_array($result_set))
	{
		?>
        <tr>
        <td><?php echo $row['file'] ?></td>
        <td><?php echo $row['type'] ?></td>
        <td><?php echo $row['size']?></td>
        <td><a href="uploads/<?php echo $row['file'] ?>" target="_blank">view file</a></td>
		
		
		
	
		 <td><a href="down.php?file=<?php echo $row['file']?>">Download file</a></td>
		 		 <td><a href="delete.php?id=<?php echo $row['id']?>">Delete file</a></td>
        </tr>
        <?php 
	}
	?>
    </table>
    </div>
	</div>
</div>
</div>
</body>
</html>