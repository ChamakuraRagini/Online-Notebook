<?php
session_start();
unset($_SESSION['user_name']);
session_destroy();

echo '<script language="javascript">';
    echo 'alert("Are u sure u want to logout??")';

	echo '</script>';

echo '<script language="javascript">';
echo 'window.location="index.php"';
echo '</script>';

exit;
?>