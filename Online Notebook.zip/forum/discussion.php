
<?php
	
	include ('content_function.php');
?>
<html>
<head><title>forum page</title></head>
<link href="/forum/styles/1.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body class="w3-container w3-gray">
<?php session_start();
?>
<nav class="frstclss">
<ul>
  <li><a href="home.php">Home</a></li>
  <li><a href="up.php">Upload</a></li>
  <li><a href="aboutus.php">About Us</a></li>
  <li><a href="discussion.php"class="active">Discussion</a></li>
    
  <li style="float:right"><a href="logout.php">Logout</a></li>
  
   <li style="float:right;margin-left:50px;color:white"><a href="view.php"> Welcome <?php echo $_SESSION['user_name'] ?> </a></li> 
</ul>
</nav>
<div class="w3-container w3-gray">

	<div class="pane">
	
	<form action="category.php" method="POST">
		<div class="createcategory">
		<b>create new post</a></b>
		
		<div class="select-style">
		<select name="year">
		<option name="first year">Select Year</option>
		<option name="first year">FIRST YEAR</option>
		<option name="second year">SECOND YEAR</option>
		<option name="third year">THIRD YEAR</option>
		<option name="fourth year">FOURTH YEAR</option>
		<option name="fifth year">FIFTH YEAR</option>
		</select></br>
		</div>
		SUBJECT<input type="text" name="subject"/></br>
		TOPIC <input type="text" name="topic"/> </br>
		<input type="submit" value="submit" name="submit"/>
		
		</div>
		
	</form>	
		<div class="content">
			<?php dispcategories(); ?>
		</div>
	</div>
	</div>
	</div>
</body>
</html>