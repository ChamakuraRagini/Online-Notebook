<?php
include ('dbconn.php');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Upload</title>
</head>

<link rel="stylesheet" href="style.css" type="text/css" /> 
<link href="/forum/styles/1.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body class="w3-container w3-gray" style="color:gray">


<?php  session_start();  ?>
<nav class="frstclss">
<ul>
  <li><a  href="home.php">Home</a></li>
  <li><a href="up.php" class="active">Upload</a></li>
  <li><a href="aboutus.php">About Us</a></li>
  <li><a href="discussion.php">Discussion</a></li>
    
  <li style="float:right"><a href="logout.php">Logout</a></li>
  
   <li style="float:right;margin-left:50px;color:white"><a href="view.php"> Welcome <?php echo $_SESSION['user_name'] ?> </a></li> 
</ul>
</nav>

<div id="body"  >

<div>

	<form action="upload.php" method="post" enctype="multipart/form-data">
	
	
	<select name="year" value="year">
	<option value="year">Select an year</option>
  <option value="first">First</option>
  <option value="second">second</option>
  <option value="third">Third</option>
  <option value="fourth">Fourth</option>
   <option value="fifth">Fifth</option>
   </select>

	<select name="sub" >
	<option value="year">choose a subject</option>
  <option value="mathematics">Mathematics</option>
  <option value="C Language">C Language</option>
  <option value="Physics">Physics</option>
  <option value="Data Structures">Data Structures</option>
   <option value="OOPS through C++">OOPS through C++</option>
    <option value="Operating Systems">Operating Systems</option>
	 <option value="Web Technologies">Web Technologies</option>
   <option value="Software Engineering">Software Engineering</option>
  <option value="Design of Algorithms">Design of Algorithms</option>
  <option value="Computer Networks">Computer Networks</option>
  <option value="Compiler Design">Compiler Design</option>
  <option value="DBMS">DBMS</option>
   <option value="Network Security">Network Security</option>
   <option value="Mobile Computing">Mobile Computing</option>
   <option value="Soft Computing">Soft Computing</option>
  <option value="Distributed Computing">Distributed Computing</option>
  <option value="Parallel& Distributed Systems">Parallel& Distributed Systems</option>
  <option value="Adhoc Sensor Networks">Adhoc Sensor Networks</option>
  <option value="Advanced Operating Systems">Advanced Operating Systems</option>
  
   </select>


	<input type="file" name="file" />
	<button type="submit" name="btn-upload">upload</button>
	</form>
    <br /><br />
    <?php
	if(isset($_GET['success']))
	{
		?>
        <label>File Uploaded Successfully...  <a href="view.php">click here to view file.</a></label>
        <?php
	}
	else if(isset($_GET['fail']))
	{
		?>
        <label>Problem While File Uploading !</label>
        <?php
	}
	else
	{
		?>
        <label>Try to upload any files(PDF, DOC, EXE, ZIP,etc...)</label>
        <?php
	}
	?>
</div>
</div>

</body>
</html>