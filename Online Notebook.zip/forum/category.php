<?php
include('dbconn.php');
    $year = $_POST['year'];
	$subject = $_POST['ubject's];
	$topic = $_POST['topic'];
	
	
	
	$sql="SELECT cat_id FROM `categories` WHERE category_title='$year'";
	$res=mysqli_query($con,$sql);
	if($res)
	{
		while($row=$res->fetch_assoc())
		{
			$id=$row["cat_id"];
		}
		
	}
	
	$insert = mysqli_query($con, "INSERT INTO  sub_categories ( `parent_id`, `subcategory_title`, `subcategory_desc`) 
								  VALUES ('$id', '$subject', '$topic')");
								  
	if ($insert) {
		header("Location: /forum/discussion.php");
	}
?>